#pragma once
#include "GameOutcome.h"


namespace assignment {
	namespace gaming {
		/// <summary>
		/// Abstract Base Class for different Game Evaluation Strategies
		/// </summary>
		class IGameStrategy {
		public:
			virtual void Evaluate(GameOutcome& outcome) = 0;
		};
	
		/// <summary>
		/// RPS - Rock Paper Scissor Game Evaluation strategy based on its rules.
		/// </summary>
		class RPSGameStrategy : public IGameStrategy {
		public:
			virtual void Evaluate(GameOutcome& outcome) override ;
		};
	}
}