#pragma once
#include <string>

namespace assignment {
	namespace gaming {

		constexpr unsigned int MOVE_CHOICES = 3;

		/// <summary>
		/// Enumeration to make the choice for Next Move
		/// </summary>
		enum class MoveChoice : int {
			ROCK,
			PAPER,
			SCISSOR,
			NONE
		};

		
		/// <summary>
	   /// Result Outcomes
	   /// </summary>
		enum class MoveResult : int {
			WON, LOSE, TIE, NONE
		};

		struct MoveResultHelper {
			static std::string ResultToString(MoveResult result)
			{
				std::string strResult;
				switch (result) {
				case MoveResult::WON: strResult = "Won"; break;
				case MoveResult::LOSE: strResult = "Lose"; break;
				case MoveResult::TIE: strResult = "Tie"; break;
				default: strResult = "NONE"; break;
				}
				return strResult;
			}
		};

		/// <summary>
		/// Helper for string conversions.
		/// </summary>
		struct MoveChoiceHelper {
			static MoveChoice CharToChoice(char ch)
			{
				MoveChoice choice;
				switch (ch) {
				case 'R': choice = MoveChoice::ROCK; break;
				case 'P': choice = MoveChoice::PAPER; break;
				case 'S': choice = MoveChoice::SCISSOR; break;
				default: choice = MoveChoice::NONE; break;
				}
				return choice;
			}
			static std::string ChoiceToString(MoveChoice choice)
			{
				std::string strChoice;
				switch (choice) {
				case MoveChoice::PAPER: strChoice = "Paper"; break;
				case MoveChoice::SCISSOR: strChoice = "Scissors"; break;
				case MoveChoice::ROCK: strChoice = "Rock"; break;
				default: strChoice = "NONE"; break;
				}
				return strChoice;
			}
			static std::string CharChoiceToString(char ch)
			{
				std::string strChoice;
				switch (ch) {
					case 'R': strChoice="r/R => Rock"; break;
					case 'P': strChoice = "p/P => Paper"; break;
					case 'S': strChoice = "s/S => Scissors"; break;
					default: strChoice = ""; break;
				}
				return strChoice;
			}

		
		};

	}
}
