#pragma once
#include "GameEngine.h"
#include "UserInterface.h"

namespace assignment {
	namespace gaming {

		/// <summary>
		/// - Report every game out come to UI 
		/// Report Summary report while exiting
		/// </summary>
		class GameReportor : public Observer<GameOutcome>
		{
		public:
			void onEvent(const GameOutcome& event) override;
			void ReportError(const char* message);
			void Print(const GameOutcome& outcome);
			void PrintAll();
		private:
			std::vector<GameOutcome> _outcomeTable;
			UserInterface UI;
		};
	}
}