#include "GameEngine.h"
#include<vector>
#include<memory>
#include "Player.h"
#include "GameOutcome.h"
#include "PlayerFactory.h"
#include "UICommandLine.h"


namespace assignment {
	namespace gaming {
		constexpr auto COMPUTER_NAME = "COMPUTER";

		GameEngine::GameEngine(PlayerType firstPlayerType, PlayerType secondPlayerType) :
			_gameStrategy(std::make_unique<RPSGameStrategy>())
		{

			auto getPlayerName = [&](PlayerType pType) {
				std::string name{};
				if (pType == PlayerType::HUMAN) {
					name = UserInterfaceCommandLine::GetUserName();
				}
				else {
					name = COMPUTER_NAME;
				}
				return name;
			};

			_firstPlayer = PlayerFactory::Create(firstPlayerType, getPlayerName(firstPlayerType));
			_secondPlayer = PlayerFactory::Create(secondPlayerType, getPlayerName(secondPlayerType));
		}

	

		/// <summary>
		/// -- Get the user choices
		///  -- Decide the winner based on player choices
		///        a) paper beats (wraps) rock,
		///        b) rock beats(blunts) scissors,
		///		   c) scissors beats(cuts) paper.
		/// </summary>
		/// <param name="playId"> unique id for the gaming session between 2 players</param>
		/// <returns>false if Game need to be stopped based on play choice</returns>

		bool GameEngine::Play(int playId) {

			bool result(true);

			GameOutcome outcome(playId);

			outcome.FirstPlayer.Name = _firstPlayer->GetName();
			outcome.SecondPlayer.Name = _secondPlayer->GetName();

			outcome.FirstPlayer.Choice = _firstPlayer->GetNextMove();
			outcome.SecondPlayer.Choice = _secondPlayer->GetNextMove();

			_gameStrategy->Evaluate(outcome);
			
			notifyAllObservers(outcome);

			return true;
		}
	}
}