#include "GameEngine.h"
#include "GameController.h"


namespace assignment {
	namespace gaming {
		//
		void GameController::PlayGame(PlayerType firstPlayerType, PlayerType secondPlayerType) 
		{
			try {
				GameEngine ge{ firstPlayerType ,secondPlayerType };
				ge.addObserver(_reportor);

				int playId{ 0 };
				while (!_stopRequested)
				{
					ge.Play(++playId);
				}

				_reportor.PrintAll();
			}
			catch (const std::exception & ex)
			{
				_reportor.ReportError(ex.what());
			}
			catch (...)
			{
				_reportor.ReportError("Stopping due to unknown exception");
			}
		}

		void GameController::StopGame() noexcept {
			_stopRequested = true;
		}
	}
}