#pragma once
#include<vector>
#include "GameOutcome.h"
namespace assignment {
	namespace gaming {

		class UserInterfaceCommandLine {
			static void DisplayRules();
			static bool waitForInput();
		public:
			static void DisplayErrorMessage(const char* message);
			static bool DisplayResult(const std::vector<GameOutcome>& outcomeTable);
			static bool DisplayResult(const GameOutcome& outcome);
			static std::string GetUserName();
			static char GetUserChoice();
		};
	}
}