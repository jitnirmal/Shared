#include "GameStrategy.h"
#include "MoveChoice.h"

namespace assignment {
	namespace gaming {

		void RPSGameStrategy::Evaluate(GameOutcome& outcome) {
			MoveChoice& choiceFirstPlayer = outcome.FirstPlayer.Choice;
			MoveChoice& choiceSecondPlayer = outcome.SecondPlayer.Choice;

			if (choiceFirstPlayer == choiceSecondPlayer) {
				outcome.FirstPlayer.Result = MoveResult::TIE;
				outcome.SecondPlayer.Result = MoveResult::TIE;
			}
			else {
				if (choiceFirstPlayer == MoveChoice::PAPER && choiceSecondPlayer == MoveChoice::ROCK) {
					outcome.FirstPlayer.Result = MoveResult::WON;
					outcome.SecondPlayer.Result = MoveResult::LOSE;
				}
				else if (choiceFirstPlayer == MoveChoice::PAPER && choiceSecondPlayer == MoveChoice::SCISSOR) {
					outcome.FirstPlayer.Result = MoveResult::LOSE;
					outcome.SecondPlayer.Result = MoveResult::WON;
				}
				else if (choiceFirstPlayer == MoveChoice::ROCK && choiceSecondPlayer == MoveChoice::PAPER) {
					outcome.FirstPlayer.Result = MoveResult::LOSE;
					outcome.SecondPlayer.Result = MoveResult::WON;
				}
				else if (choiceFirstPlayer == MoveChoice::ROCK && choiceSecondPlayer == MoveChoice::SCISSOR) {
					outcome.FirstPlayer.Result = MoveResult::WON;
					outcome.SecondPlayer.Result = MoveResult::LOSE;
				}
				else if (choiceFirstPlayer == MoveChoice::SCISSOR && choiceSecondPlayer == MoveChoice::PAPER) {
					outcome.FirstPlayer.Result = MoveResult::WON;
					outcome.SecondPlayer.Result = MoveResult::LOSE;
				}
				else if (choiceFirstPlayer == MoveChoice::SCISSOR && choiceSecondPlayer == MoveChoice::ROCK) {
					outcome.FirstPlayer.Result = MoveResult::LOSE;
					outcome.SecondPlayer.Result = MoveResult::WON;
				}
				else {
					// no case left
				}
			}
		};
	}
}