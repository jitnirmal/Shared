#pragma once
#include<vector>
#include<memory>
#include "Player.h"
#include "GameOutcome.h"
#include "PlayerFactory.h"
#include "GameStrategy.h"
#include "Observer.h"


namespace assignment {
	namespace gaming {

		/// <summary>
		/// GameEngine - Plays the Game between 2 Players.
		/// Uses Game Strategy for the Rules and GameOutcome
		/// </summary>
		class GameEngine : public Observable<GameOutcome>
		{
		public:
			GameEngine(PlayerType firstPlayerType, PlayerType secondPlayerType);
		    bool Play(int playId);
		private:
			std::unique_ptr<IPlayer> _firstPlayer;
			std::unique_ptr<IPlayer> _secondPlayer;
			std::unique_ptr<IGameStrategy> _gameStrategy;
		};
	}
}