#pragma once
#include <vector>
#include "GameOutcome.h"


namespace assignment {
	namespace gaming {

		/// <summary>
		/// Class to interface UserInterface. It aims to plug the different UserInterface (UICommandLine, or NW based in coming time.) to GameEngine
		/// </summary>
		class UserInterface {
		public:
			void DisplayErrorMessage(const char* message);
			bool DisplayResult(const std::vector<GameOutcome>& outcomeTable);
			bool DisplayResult(const GameOutcome& outcome);
			std::string GetUserName();
			char GetUserChoice();
		};

	}
}