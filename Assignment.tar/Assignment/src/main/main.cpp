#include "Player.h"

#include "CompileTimeVisitor.h"
#include "RunTimeVisitorAcyclic.h"
#include "RunTimeVisitorCyclic.h"
#include "GameController.h"
#include <iostream>

void testVisitorPerformance()
{
	auto ctvsResult = assignment::ctvs::test_ctvs();
	std::cout << "Time Take for Compile Time Visitor : " << ctvsResult << " nano secs" << std::endl;

	auto rtvcResult = assignment::rtvc::test_rtvc();
	std::cout << "Time Take for RT Cyclic Visitor  : " << rtvcResult << " nano secs" << std::endl;

	auto rtvaResult = assignment::rtva::test_rtva();
	std::cout << "Time Take for RT ACyclic Visitor  : " << rtvaResult << " nano secs" << std::endl;
}
int main()
{
	using namespace assignment::gaming;
	GameController::Instance().PlayGame(PlayerType::COMPUTER,PlayerType::HUMAN);
	//testVisitorPerformance();
	return 0;
}