#include <boost/test/unit_test.hpp>
#include <boost/test/floating_point_comparison.hpp>
#include "GameStrategy.h"
#include "GameOutcome.h"
#include "Player.h"
#include <memory>

BOOST_AUTO_TEST_SUITE(RPSTests)
/// <summary>
/// Game Rules
/// 	- paper beats (wraps) rock,
/// 	- rock beats(blunts) scissors,
/// 	- scissors beats(cuts) paper.
BOOST_AUTO_TEST_CASE(RPSTestGameRulesTIE_1)
{
	using namespace assignment::gaming;
	auto rpsStrategy = std::make_unique<RPSGameStrategy>();

	int gameId{ 1 };
	GameOutcome outcome(gameId);

	outcome.FirstPlayer.Name = "Player1";
	outcome.FirstPlayer.Choice = MoveChoice::PAPER;
	outcome.SecondPlayer.Name = "Player2";
	outcome.SecondPlayer.Choice = MoveChoice::PAPER;

	rpsStrategy->Evaluate(outcome);

	BOOST_CHECK(outcome.FirstPlayer.Result == MoveResult::TIE);
	BOOST_CHECK(outcome.SecondPlayer.Result == MoveResult::TIE);

}

/// <summary>
/// Test the Paper vs Scissor
/// </summary>
BOOST_AUTO_TEST_CASE(RPSTestGameRulesPaperScissor_2)
{
	using namespace assignment::gaming;
	auto rpsStrategy = std::make_unique<RPSGameStrategy>();

	int gameId{ 1 };
	GameOutcome outcome(gameId);

	outcome.FirstPlayer.Name = "Player1";
	outcome.FirstPlayer.Choice = MoveChoice::PAPER;
	outcome.SecondPlayer.Name = "Player2";
	outcome.SecondPlayer.Choice = MoveChoice::SCISSOR;

	rpsStrategy->Evaluate(outcome);

	BOOST_CHECK(outcome.FirstPlayer.Result == MoveResult::LOSE);
	BOOST_CHECK(outcome.SecondPlayer.Result == MoveResult::WON);

}


/// <summary>
/// Test the Rock vs Paper
/// </summary>

BOOST_AUTO_TEST_CASE(RPSTestGameRulesRockPaper_3)
{
	using namespace assignment::gaming;
	auto rpsStrategy = std::make_unique<RPSGameStrategy>();

	int gameId{ 1 };
	GameOutcome outcome(gameId);

	outcome.FirstPlayer.Name = "Player1";
	outcome.FirstPlayer.Choice = MoveChoice::ROCK;
	outcome.SecondPlayer.Name = "Player2";
	outcome.SecondPlayer.Choice = MoveChoice::PAPER;

	rpsStrategy->Evaluate(outcome);

	BOOST_CHECK(outcome.FirstPlayer.Result == MoveResult::LOSE);
	BOOST_CHECK(outcome.SecondPlayer.Result == MoveResult::WON);

}

/// <summary>
/// Test the Rock vs Scissor
/// </summary>
BOOST_AUTO_TEST_CASE(RPSTestGameRulesRockScissors_3)
{
	using namespace assignment::gaming;
	auto rpsStrategy = std::make_unique<RPSGameStrategy>();

	int gameId{ 1 };
	GameOutcome outcome(gameId);

	outcome.FirstPlayer.Name = "Player1";
	outcome.FirstPlayer.Choice = MoveChoice::ROCK;
	outcome.SecondPlayer.Name = "Player2";
	outcome.SecondPlayer.Choice = MoveChoice::SCISSOR;

	rpsStrategy->Evaluate(outcome);

	BOOST_CHECK(outcome.FirstPlayer.Result == MoveResult::WON);
	BOOST_CHECK(outcome.SecondPlayer.Result == MoveResult::LOSE);

}


BOOST_AUTO_TEST_SUITE_END()