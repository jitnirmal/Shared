#include <boost/test/unit_test.hpp>
#include <boost/test/floating_point_comparison.hpp>
#include "CompileTimeVisitor.h"
#include "RunTimeVisitorAcyclic.h"
#include "RunTimeVisitorCyclic.h"

constexpr double TOLERANCE = 0.0001;


BOOST_AUTO_TEST_SUITE(VisitorTestWithShapes)

BOOST_AUTO_TEST_CASE(CompileTimeVisitorSimpleTest_1)
{
	constexpr double radius{ 3.2 };
	assignment::ctvs::Circle c(radius);

	constexpr double base{ 4.0 };
	constexpr double height{ 5.5 };
	assignment::ctvs::Triangle t(base, height);

	constexpr double length{ 3.2 };
	constexpr double breadth{ 4.1 };
	assignment::ctvs::Rectangle r(length, breadth);

	assignment::ctvs::AreaVisitor av;
	assignment::ctvs::Shape::accept(c, av);
	assignment::ctvs::Shape::accept(t, av);
	assignment::ctvs::Shape::accept(r, av);

	BOOST_CHECK_CLOSE_FRACTION(av.GetCircleArea(), assignment::ctvs::PI* radius, TOLERANCE);
	BOOST_CHECK_CLOSE_FRACTION(av.GetRectangleArea(), length * breadth, TOLERANCE);
	BOOST_CHECK_CLOSE_FRACTION(av.GetTriangleArea(), base * height * 0.5, TOLERANCE);

}

BOOST_AUTO_TEST_CASE(RunTimeVisitorACyclicTest_2)
{
	
	constexpr double radius{ 3.2 };
	assignment::rtva::Circle c(radius);

	constexpr double base{ 4.0 };
	constexpr double height{ 5.5 };
	assignment::rtva::Triangle t(base, height);

	constexpr double length{ 3.2 };
	constexpr double breadth{ 4.1 };
	assignment::rtva::Rectangle r(length, breadth);

	assignment::rtva::AreaVisitor av;
	c.accept(av);
	r.accept(av);
	t.accept(av);
	
	BOOST_CHECK_CLOSE_FRACTION(av.GetCircleArea(), assignment::rtva::PI * radius, TOLERANCE);
	BOOST_CHECK_CLOSE_FRACTION(av.GetRectangleArea(), length * breadth, TOLERANCE);
	BOOST_CHECK_CLOSE_FRACTION(av.GetTriangleArea(), base * height * 0.5, TOLERANCE);

}


BOOST_AUTO_TEST_CASE(RunTimeVisitorCyclicTest_3)
{

	constexpr double radius{ 3.2 };
	assignment::rtvc::Circle c(radius);

	constexpr double base{ 4.0 };
	constexpr double height{ 5.5 };
	assignment::rtvc::Triangle t(base, height);

	constexpr double length{ 3.2 };
	constexpr double breadth{ 4.1 };
	assignment::rtvc::Rectangle r(length, breadth);

	assignment::rtvc::AreaVisitor av;
	c.accept(av);
	r.accept(av);
	t.accept(av);

	BOOST_CHECK_CLOSE_FRACTION(av.GetCircleArea(), assignment::rtva::PI * radius, TOLERANCE);
	BOOST_CHECK_CLOSE_FRACTION(av.GetRectangleArea(), length * breadth, TOLERANCE);
	BOOST_CHECK_CLOSE_FRACTION(av.GetTriangleArea(), base * height * 0.5, TOLERANCE);

}

BOOST_AUTO_TEST_SUITE_END()