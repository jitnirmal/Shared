#pragma once
#include <iostream>
#include <memory>
#include <cassert>
#include <chrono>
namespace assignment {
	namespace rtvc {
		static constexpr double PI = 3.14;

		/// <summary>
		/// This is classic Visitor pattern implementation, which implements the double
		///  dispatch at run-time and  the program selects which code to run based on two factors, 
		/// the types of the visitor and the visitable objects. This implementation key disadvantage 
		/// is that it puts cyclic dependency between Visitor and Visitable classes. Whenever there
		///  is new class added to hierarchy, the source code containing the visited hierarchy need to be recompiled
		/// </summary>
		template <typename ... Types>
		class Visitor;

		template <typename T>
		class Visitor<T> {
		public:
			virtual void visit(T& t) = 0;
		};

		template <typename T, typename ... Types>
		class Visitor<T, Types ...> : public Visitor<Types ...> {
		public:
			using Visitor<Types ...>::visit;
			virtual void visit(T& t) = 0;
		};
		
		using ShapeVisitor = Visitor<class Circle, class Triangle, class Rectangle>;


		/// <summary>
		/// Visitable with Shape Heirarchy
		/// </summary>
		class Shape {
		public:
			Shape() = default;
			virtual ~Shape() = default;
			explicit Shape(const std::string& name) noexcept : _name(name) {}
			const std::string& name() const noexcept { return _name; }
			/// <summary>
			virtual void accept(ShapeVisitor& v) = 0;
		private:
			std::string _name;
		};

		template <typename Derived>
		class Visitable : public Shape {
		public:
			Visitable() {};
			void accept(ShapeVisitor& v) override {
				v.visit(*(static_cast<Derived*>(this)));
			}
		};

		class Circle : public Visitable<Circle> {
		public:
			explicit Circle(double radius) noexcept : _radius(radius) {}
			inline double GetRadius() const noexcept { return _radius; }
		private:
			double _radius{ 0.0 };
		};

		class Triangle : public Visitable<Triangle> {
		public:
			Triangle() = default;
			Triangle(double base, double height) noexcept : _base(base), _height(height) {}
			inline double GetBase() const noexcept { return _base; }
			inline double GetHeight() const noexcept { return _height; }
		private:
			double _base{ 0.0 };
			double _height{ 0.0 };
		};

		class Rectangle : public Visitable<Rectangle> {
		public:
			Rectangle() = default;
			Rectangle(double length, double breadth) noexcept : _length(length), _breadth(breadth) {}
			inline double GetLength() const noexcept { return _length; }
			inline double GetBreadth() const noexcept { return _breadth; }
		private:
			double _length{ 0.0 };
			double _breadth{ 0.0 };
		};

		class AreaVisitor : public ShapeVisitor {
		public:
			void visit(Circle& c) {
				_circleArea = PI * c.GetRadius();
			}
			void visit(Triangle& t) {
				_triangleArea = t.GetBase() * t.GetHeight() * 0.5;
			}
			void visit(Rectangle& r) {
				_rectangleArea = r.GetBreadth() * r.GetLength();
			}
		public:
			inline double GetCircleArea() const noexcept { return _circleArea; }
			inline double GetTriangleArea() const noexcept { return _triangleArea; }
			inline double GetRectangleArea() const noexcept { return _rectangleArea; }
		private:
			double _circleArea{ 0.0 };
			double _triangleArea{ 0.0 };
			double _rectangleArea{ 0.0 };
		};
		auto test_rtvc()
		{
			constexpr double radius{ 3.2 };
			Circle c(radius);

			constexpr double base{ 4.0 };
			constexpr double height{ 5.5 };
			Triangle t(base, height);

			constexpr double length{ 3.2 };
			constexpr double breadth{ 4.1 };
			Rectangle r(length, breadth);

			AreaVisitor av;

			constexpr int COUNT{ 10000 };
			auto start = std::chrono::steady_clock::now();
			for (int i = 0; i < COUNT; ++i) {
				c.accept(av);
				t.accept(av);
				r.accept(av);
			}
			auto end = std::chrono::steady_clock::now();
			return std::chrono::duration_cast<std::chrono::nanoseconds>(end - start).count() / COUNT;
		}
	} //rtvc

} // assignment
