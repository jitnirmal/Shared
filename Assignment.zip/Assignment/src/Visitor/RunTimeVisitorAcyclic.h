#pragma once
#include <iostream>
#include <memory>
#include <cassert>
#include <chrono>
namespace assignment {

	namespace rtva {
		static constexpr double PI = 3.14;

		/// <summary>
		/// This variation of Acyclic Visitor successfully resolves the cyclic dependency issue between 
		/// Visitor and Visitable class hierarchy. However, it needs to use dynamic cast, 
		/// which is expensive in terms of performance. 
		/// </summary>

		class VisitorBase {
		public:
			virtual ~VisitorBase() = default;
		};

		template <typename Visitable>
		class Visitor {
		public:
			virtual void visit(Visitable& p) = 0;
		};

		template <typename Base, typename Visitable>
		class VisitableBase : public Base {
		public:
			using Base::Base;
			void accept(VisitorBase& vb) override {
				if (auto v = dynamic_cast<Visitor<Visitable>*>(&vb))
					v->visit(*(static_cast<Visitable*>(this)));
				else {  
					assert(false);
				}
			}
		};


		class Shape {
		public:
			virtual ~Shape() = default;
			Shape() = default;
			explicit Shape(const std::string& name) noexcept : _name(name) {}
			inline const std::string& name() const noexcept { return _name; }
			virtual void accept(VisitorBase& v) = 0;
		private:
			std::string _name;
		};


		template <typename Visitable>
		using ShapeVisitable = VisitableBase<Shape, Visitable>;


		class Circle : public ShapeVisitable<Circle> {
		public:
			explicit Circle(double radius) noexcept : _radius(radius) {}
			inline double GetRadius() const noexcept { return _radius; }
		private:
			double _radius{ 0.0 };
		};

		class Triangle : public ShapeVisitable<Triangle> {
		public:
			Triangle() = default;
			Triangle(double base, double height) noexcept : _base(base), _height(height) {}
			inline const double GetBase() const noexcept { return _base; }
			inline const double GetHeight() const noexcept { return _height; }
		private:
			double _base{ 0.0 };
			double _height{ 0.0 };
		};

		class Rectangle : public ShapeVisitable<Rectangle> {
		public:
			Rectangle() = default;
			Rectangle(double length, double breadth) noexcept : _length(length), _breadth(breadth) {}
			inline double GetLength() const noexcept { return _length; }
			inline double GetBreadth() const noexcept { return _breadth; }
		private:
			double _length{ 0.0 };
			double _breadth{ 0.0 };
		};

		class AreaVisitor : public VisitorBase, public Visitor<Circle>, public Visitor<Triangle>, public Visitor<Rectangle> {
			void visit(Circle& c) {
				_circleArea = PI * c.GetRadius();
			}
			void visit(Triangle& t) {
				_triangleArea = t.GetBase() * t.GetHeight() * 0.5;
			}
			void visit(Rectangle& r) {
				_rectangleArea = r.GetBreadth() * r.GetLength();
			}
		public:
			inline double GetCircleArea() const noexcept { return _circleArea; }
			inline double GetTriangleArea() const noexcept { return _triangleArea; }
			inline double GetRectangleArea() const noexcept { return _rectangleArea; }
		private:
			double _circleArea{ 0.0 };
			double _triangleArea{ 0.0 };
			double _rectangleArea{ 0.0 };
		};

		auto test_rtva()
		{
			constexpr double radius{ 3.2 };
			Circle c(radius);

			constexpr double base{ 4.0 };
			constexpr double height{ 5.5 };
			Triangle t(base, height);

			constexpr double length{ 3.2 };
			constexpr double breadth{ 4.1 };
			Rectangle r(length, breadth);

			AreaVisitor av;

			constexpr int COUNT{ 10000 };
			auto start = std::chrono::steady_clock::now();
			for (int i = 0; i < COUNT; ++i) {
				c.accept(av);
				t.accept(av);
				r.accept(av);
			}
			auto end = std::chrono::steady_clock::now();
			return std::chrono::duration_cast<std::chrono::nanoseconds>(end - start).count() / COUNT;
		}
	} //rtva

} // assignment
