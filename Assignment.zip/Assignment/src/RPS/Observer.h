#pragma once
#include <set>
namespace assignment {
	namespace gaming {

		template<class TEvent>
		class Observer
		{
		public:
			Observer() {};
			virtual ~Observer() {};

			virtual void onEvent(const TEvent&) = 0;

		};


		template<class TEvent>
		class Observable
		{
		public:
			Observable() {};
			virtual ~Observable() {};

			void addObserver(Observer<TEvent>& observer) {
				_observers.insert(&observer);
			}
			void removeObserver(Observer<TEvent>& observer) {
				_observers.erase(&observer);
			}

		protected:
			using Observers = std::set<Observer<TEvent>*>;

			void notifyAllObservers(const TEvent& evt) const {
				for (auto& observer : _observers)
				{
					observer->onEvent(evt);
				}
			}

			bool hasObservers() {
				return !_observers.empty();
			}
			Observers _observers;
		};
	}
}