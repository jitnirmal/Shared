#include "UserInterface.h"
#include "UICommandLine.h"

namespace assignment {
	namespace gaming {

		void UserInterface::DisplayErrorMessage(const char* message){
			UserInterfaceCommandLine::DisplayErrorMessage(message);
		}

		bool UserInterface::DisplayResult(const std::vector<GameOutcome>& outcomeTable) {
			return UserInterfaceCommandLine::DisplayResult(outcomeTable);
		}

		bool UserInterface::DisplayResult(const GameOutcome& oc) {
			return UserInterfaceCommandLine::DisplayResult(oc);
			
		}
		std::string UserInterface::GetUserName() {
			return UserInterfaceCommandLine::GetUserName();
		}
		
		char UserInterface::GetUserChoice(){
			return UserInterfaceCommandLine::GetUserChoice();
		}

	}
}