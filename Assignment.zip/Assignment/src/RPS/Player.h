#pragma once
#include "MoveChoice.h"

namespace assignment {
	namespace gaming {

		enum class PlayerType : int {
			HUMAN, COMPUTER, NONE
		};

		/// <summary>
		/// Abstract base class for Player
		/// </summary>
		class IPlayer {
		public:
			/// <summary>
			/// constructor
			/// </summary>
			/// <param name="name">Name of the Player</param>
			IPlayer(const std::string& name) noexcept :_name(name) {}
			

			/// <summary>
			/// To find the next Move Choice of the Player.
			/// Must be overridden by concrete classes
			/// </summary>
			/// <returns></returns>
			virtual MoveChoice GetNextMove() = 0;
			
			inline std::string GetName() const noexcept {
				return _name;
			}

			/// <summary>
			/// Update the outcome for the player. Useful for final reporting etc.
			/// </summary>
			/// <param name="moveResult"></param>
			void UpdateOutcome(MoveResult moveResult);
			

		protected:
			std::string _name;
			int _winCount{ 0 };
			int _loseCount{ 0 };
		};


		class HumanPlayer : public IPlayer {
		public:
			HumanPlayer(const std::string& name) noexcept;
			MoveChoice GetNextMove() override;
		};

		class ComputerPlayer : public IPlayer {
		public:
			ComputerPlayer(const std::string& name) noexcept;
			MoveChoice GetNextMove() override;
			
		};
	}
}