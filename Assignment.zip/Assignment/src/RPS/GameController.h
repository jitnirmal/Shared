#pragma once
#include "Player.h"
#include "GameReporter.h"

namespace assignment {
	namespace gaming {
		/// <summary>
		/// Singelton Controller class for RPS Game Engine.
		/// </summary>
		class GameController
		{
			GameController() = default;
			GameController(GameController const&) = delete;
			GameController& operator=(GameController const&) = delete;
		public:
			/// <summary>
			/// Singleton Static Instance
			/// </summary>
			/// <returns></returns>
			static GameController& Instance() noexcept{
				static GameController single;
				return single;
			}
			/// <summary>
			/// Play Game trigger the Game Engines. 
			/// </summary>
			/// <param name="firstPlayerType">First Player Type - Computer/Human</param>
			/// <param name="secondPlayerType">First Player Type - Computer/Human</param>
			void PlayGame(PlayerType firstPlayerType, PlayerType secondPlayerType);
			void StopGame() noexcept;
		private:
			GameReportor _reportor;
			bool _stopRequested {false};
		};
	}
}