#pragma once
#include <string>
#include "MoveChoice.h"


namespace assignment {
	namespace gaming {

		struct PlayerInfo
		{
			std::string Name;
			MoveChoice Choice{ MoveChoice::NONE };
			MoveResult Result{ MoveResult::TIE };
		};

		struct GameOutcome
		{
			GameOutcome(int outcomeId) :OutcomeId(outcomeId) {}
			int OutcomeId{ 0 };
			PlayerInfo FirstPlayer;
			PlayerInfo SecondPlayer;
		};
	}
}