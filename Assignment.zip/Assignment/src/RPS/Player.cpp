#include "Player.h"
#include <ctime>
#include <string>
#include <iostream>
#include "UICommandLine.h"


namespace assignment {
	namespace gaming {
	
		/// <summary>
		/// IPlayer  
		/// </summary>
		void IPlayer::UpdateOutcome(MoveResult moveResult) {
		
			if (moveResult == MoveResult::WON) {
				++_winCount;
			}
			else if (moveResult == MoveResult::LOSE){
				++_loseCount;
			}
			else{
				// TIE
			}
		}

		/// <summary>
		/// HumanPlayer 
		/// </summary>

		HumanPlayer::HumanPlayer(const std::string& name) noexcept
			:IPlayer(name) {}

	
		/// <summary>
		/// HumanPlayer next move seeks user input through UI.
		/// </summary>
		MoveChoice HumanPlayer::GetNextMove() {
			char choiceChar = std::toupper(UserInterfaceCommandLine::GetUserChoice());
			return MoveChoiceHelper::CharToChoice(choiceChar);
		}

		ComputerPlayer::ComputerPlayer(const std::string& name) noexcept
			:IPlayer(name) {}

		/// <summary>
		/// ComputerPlayer next move uses random function to find next move.
		/// </summary>
		MoveChoice ComputerPlayer::GetNextMove() {
			
			std::srand(static_cast<unsigned int>(std::time(nullptr))); 
			return static_cast<MoveChoice>(std::rand() % MOVE_CHOICES);
		}
	}
}

