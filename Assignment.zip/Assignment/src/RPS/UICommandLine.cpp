#include <iostream>
#include <iomanip>
#include <cstdlib>
#include <string>
#include <sstream>
#include "GameOutcome.h"
#include "MoveChoice.h"
#include "UICommandLine.h"

namespace assignment {
	namespace gaming {

#define RST  "\x1B[0m"
#define KRED  "\x1B[31m"
#define KGRN  "\x1B[32m"
#define KYEL  "\x1B[33m"
#define KBLU  "\x1B[34m"
#define KMAG  "\x1B[35m"
#define KCYN  "\x1B[36m"
#define KWHT  "\x1B[37m"

#define FRED(x) KRED x RST
#define FGRN(x) KGRN x RST
#define FYEL(x) KYEL x RST
#define FBLU(x) KBLU x RST
#define FMAG(x) KMAG x RST
#define FCYN(x) KCYN x RST
#define FWHT(x) KWHT x RST

#define BOLD(x) "\x1B[1m" x RST
#define UNDL(x) "\x1B[4m" x RST

		void UserInterfaceCommandLine::DisplayErrorMessage(const char* message)
		{
			if (system("CLS")) system("clear");
			std::cout << "Error Message reported : " << message << std::endl;
		}

		void UserInterfaceCommandLine::DisplayRules()
		{
			if (system("CLS")) system("clear");
			std::cout << BOLD(UNDL(FGRN("\nGame follows following rules \n\n"))) << std::endl;
			std::cout << BOLD(FYEL("1) Paper (P) beats (wraps) Rock(R) ")) << std::endl;
			std::cout << BOLD(FYEL("2) Rock (R) beats (blunts) Scissors(S) ")) << std::endl;
			std::cout << BOLD(FYEL("3) Scissors (S) beats (cuts) Paper(P) \n")) << std::endl;
		}

		bool UserInterfaceCommandLine::waitForInput()
		{
			std::cout << '\n' << "Press e/E to Exit or any key to continue...";
			std::cin.ignore();
			std::string ip;
			std::getline(std::cin, ip);
			if (std::toupper(ip[0]) == 'E')
			{
				std::cout << '\n' << "you choose to Exit. Are you Sure ? Y/y to confirm. Any key to continue ";
				std::getline(std::cin, ip);
				if (std::toupper(ip[0]) == 'Y')
				{
					return false;
				}
			}
			return true;
		}
		bool UserInterfaceCommandLine::DisplayResult(const std::vector<GameOutcome>& outcomeTable) {
			if (system("CLS")) system("clear");
			std::cout << BOLD(UNDL(FGRN("\t\t\t\tSummary of Rock-Paper-Scissor Game\n\n"))) << std::endl;
			std::cout << BOLD(FMAG("==================================================================================================")) << std::endl;
			std::cout << BOLD(FWHT(" Game ID         || Player1 Name,   Choice,    Result  ||  Player2 Name,   Choice,     Result  || ")) << std::endl;
			std::cout << BOLD(FMAG("==================================================================================================")) << std::endl;
			for (const auto& item : outcomeTable)
			{
				std::stringstream ss;
				ss << std::setw(10)<< item.OutcomeId << std::setw(10) << " || "
					<< std::setw(10)<< item.FirstPlayer.Name << ", "
					<< std::setw(10)<< MoveChoiceHelper::ChoiceToString(item.FirstPlayer.Choice)<< ", " 
					<< std::setw(10)<<MoveResultHelper::ResultToString(item.FirstPlayer.Result)	<< " || " 
					<< std::setw(10)<< item.SecondPlayer.Name << ", " 
					<< std::setw(10) << MoveChoiceHelper::ChoiceToString(item.SecondPlayer.Choice) << ", "
					<< std::setw(10) << MoveResultHelper::ResultToString(item.SecondPlayer.Result) << " ||";
				std::cout << ss.str().c_str() << std::endl;
			}
			std::cout << BOLD(FMAG("==================================================================================================")) << std::endl;
			return waitForInput();
		}

		bool UserInterfaceCommandLine::DisplayResult(const GameOutcome& outcome)
		{
			DisplayRules();
			std::cout << BOLD(UNDL(FGRN("Outcome of Rock-Paper-Scissor Game\n\n"))) << std::endl;
			std::cout << BOLD(FMAG("===============================")) << std::endl;
			std::cout << BOLD(FWHT(" - Game ID        : ")) << outcome.OutcomeId << std::endl;
			std::cout << BOLD(FMAG("===============================")) << std::endl;
			std::cout << BOLD(FYEL(" - Player1 Name   : ")) << outcome.FirstPlayer.Name << std::endl;
			std::cout << BOLD(FYEL(" - Player1 Choice : ")) << MoveChoiceHelper::ChoiceToString(outcome.FirstPlayer.Choice) << std::endl;
			std::cout << BOLD(FYEL(" - Player1 Result : ")) << MoveResultHelper::ResultToString(outcome.FirstPlayer.Result) << std::endl;
			std::cout << BOLD(FMAG("===============================")) << std::endl;
			std::cout << BOLD(FGRN(" - Player2 Name   : ")) << outcome.SecondPlayer.Name << std::endl;
			std::cout << BOLD(FGRN(" - Player2 Choice : ")) << MoveChoiceHelper::ChoiceToString(outcome.SecondPlayer.Choice) << std::endl;
			std::cout << BOLD(FGRN(" - Player2 Result : ")) << MoveResultHelper::ResultToString(outcome.SecondPlayer.Result) << std::endl;
			std::cout << BOLD(FMAG("===============================")) << std::endl;
			return waitForInput();
		}

		std::string UserInterfaceCommandLine::GetUserName()
		{
			while (true) {
				if (system("CLS")) system("clear");
				std::cout << "\t\t\t\t" << BOLD(UNDL(FGRN("Welcome to Rock-Paper-Scissor Game\n\n"))) << std::endl;
				std::cout << BOLD(FYEL("You can play this Game with Computer\n")) << std::endl;
				std::cout << BOLD(FYEL("Please enter your name : "));
				std::string name;
				std::cin >> name;
				std::cout << BOLD(FYEL("You entered name as : ")) << name;
				std::cout << BOLD(FMAG("\n\nPress n/N - If want to change, else any other key to contine....")) << std::endl;
				std::string option;
				std::cin.ignore();
				std::getline(std::cin, option);
				if (std::toupper(option[0]) != 'N')
				{
					return name;
				}
			}
		}
		
		char UserInterfaceCommandLine::GetUserChoice() {

			static const std::string validChars = "RPS";
			char ch = ' ';
			bool firstTime = false;
			while (true) {
				if (system("CLS")) system("clear");
				if (firstTime == false) {
					std::cout << BOLD(FYEL("You chose an invalid choice : ")) << ch << BOLD(FYEL(" Lets try again")) << std::endl;
				}
				firstTime = false;
				std::cout << BOLD(UNDL(FGRN("\nGame follows following rules \n\n"))) << std::endl;
				std::cout << BOLD(FYEL("1) Paper (P) beats (wraps) Rock(R) ")) << std::endl;
				std::cout << BOLD(FYEL("2) Rock (R) beats (blunts) Scissors(S) ")) << std::endl;
				std::cout << BOLD(FYEL("3) Scissors (S) beats (cuts) Paper(P) \n")) << std::endl;

				std::cout << BOLD(FCYN("Please specify one choice for your next move")) << BOLD(FWHT("\n\t - Rock(r/R) \n\t - Scissors(s/S) \n\t - Paper(p/P) \n\n")) << std::endl;
				std::cin >> ch;
				ch = std::toupper(ch);
				if (validChars.find(ch) != std::string::npos) {
					std::cout << BOLD(FYEL("You choose : ")) << MoveChoiceHelper::CharChoiceToString(ch) << std::endl;
					break;
				}
			}
			return ch;
		}


	}
}
