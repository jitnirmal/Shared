#pragma once
#include <map>
#include <memory>
#include <functional>
#include "Player.h"

namespace assignment {
	namespace gaming {

		/// <summary>
		/// Factory to help with heirarchy of Player Objects.
		/// Return unique_ptr to object - RAII
		/// </summary>
		struct PlayerFactory
		{
		public:
			static std::unique_ptr<IPlayer> Create(const PlayerType type, const std::string& name)
			{
				switch (type) {
				case PlayerType::HUMAN: return std::make_unique<HumanPlayer>(name);
				case PlayerType::COMPUTER: return std::make_unique<ComputerPlayer>(name);
				default: return nullptr;
				}
			}
		};
	}
}
