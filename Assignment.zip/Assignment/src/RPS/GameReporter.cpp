#include "GameReporter.h"
#include "GameController.h"

namespace assignment {
	namespace gaming {
		void GameReportor::onEvent(const GameOutcome& outcome) {
			_outcomeTable.push_back(outcome);
			Print(outcome);
		}
		void GameReportor::Print(const GameOutcome& outcome) {
			if (UI.DisplayResult(outcome) == false)
			{
				GameController::Instance().StopGame();
			}
		}

		void GameReportor::PrintAll() {
			UI.DisplayResult(_outcomeTable);
		}

		void GameReportor::ReportError(const char* message){
			UI.DisplayErrorMessage(message);
		}
	}
}